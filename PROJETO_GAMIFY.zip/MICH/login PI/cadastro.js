document.getElementById('cadastroForm').addEventListener('submit', function(event) {
    event.preventDefault();

    var senha = document.getElementById('senha').value;
    var confirmarSenha = document.getElementById('confirmarSenha').value;
    var errorMessage = document.getElementById('error-message');

    // Verificar se as senhas coincidem
    if (senha !== confirmarSenha) {
        errorMessage.textContent = "As senhas não coincidem!";
        return;
    }

    // Verificar se o checkbox dos termos foi marcado
    if (!document.getElementById('aceitoTermos').checked) {
        errorMessage.textContent = "Você deve aceitar os termos de serviço e a política de privacidade.";
        return;
    }

    // Se passar nas validações, podemos simular o envio do formulário
    alert("Cadastro realizado com sucesso!");

    // Aqui você pode adicionar código para enviar os dados do formulário para um servidor
});
