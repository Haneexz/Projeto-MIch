const express = require('express');
const mysql = require('mysql2');
const bodyParser = require('body-parser');

const app = express();
const port = 3000;

// Configurar o MySQL
const db = mysql.createConnection({
    host: 'localhost',
    user: 'root', // Substitua pelo seu usuário MySQL
    password: 'senac', // Substitua pela sua senha MySQL
    database: 'loginDB',
});

// Conectar ao banco de dados
db.connect((err) => {
    if (err) {
        console.error('Erro ao conectar ao banco de dados: ' + err.stack);
        return;
    }
    console.log('Conectado ao banco de dados MySQL');
});

// Middleware para processar o corpo da requisição
app.use(bodyParser.urlencoded({ extended: true }));
app.use(bodyParser.json());

// Rota de login
app.post('/login', (req, res) => {
    const { nome, password } = req.body;

    // Verifica as credenciais no banco de dados
    const query = 'SELECT * FROM users WHERE nome = ? AND password = ?';
    db.execute(query, [nome, password], (err, results) => {
        if (err) {
            return res.status(500).json({ message: 'Erro no servidor' });
        }

        if (results.length > 0) {
            res.json({ success: true, message: 'Login bem-sucedido!' });
        } else {
            res.status(401).json({ success: false, message: 'Usuário ou senha inválidos.' });
        }
    });
});

// Iniciar o servidor
app.listen(port, () => {
    console.log(`Servidor rodando na porta ${port}`);
});
