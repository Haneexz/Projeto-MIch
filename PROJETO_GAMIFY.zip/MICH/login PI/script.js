document.getElementById('loginForm').addEventListener('submit', function (event) {
    event.preventDefault(); // Impede o envio do formulário

    var nome = document.getElementById('nome').value;
    var password = document.getElementById('password').value;
    var errorMessage = document.getElementById('error-message');

    let buttonCadastrar = document.querySelector('#cadastrar')
    buttonCadastrar.addEventListener('click', () =>{
        window.location.href = 'cadastrar.html'
    })

    // Envia os dados de login para o servidor
    fetch('http://localhost:3000/login', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
        },
        body: JSON.stringify({ nome: nome, password: password })
    })
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                errorMessage.textContent = "";
                alert(data.message);
                // Redirecionar após login bem-sucedido
                window.location.href = "pagina_inicial.html";
            } else {
                errorMessage.textContent = data.message;
            }
        })
        .catch(error => {
            errorMessage.textContent = "Erro de conexão. Tente novamente.";
        });
});


// separação de script - parte da IA (padrão) separado do script do form sw login:

function toggleChat() {
    const chatPopup = document.getElementById('chatPopup');
    chatPopup.style.display = chatPopup.style.display === 'none' || chatPopup.style.display === '' ? 'block' : 'none';
}

function sendWhatsAppMessage() {
    const name = document.getElementById('name').value;
    const phone = document.getElementById('phone').value;
    const email = document.getElementById('email').value;
    const company = document.getElementById('company').value;
    const role = document.getElementById('role').value;
    const size = document.getElementById('size').value;

    if (!name || !phone || !email || !company || !role || !size) {
        alert('Por favor, preencha todos os campos obrigatórios.');
        return;
    }

    const message = `Olá, meu nome é ${name}.\nEmpresa: ${company}\nCargo: ${role}\nColaboradores: ${size}\nEmail: ${email}\nTelefone: ${phone}`;
    const whatsappURL = 'https://api.whatsapp.com/send?phone=YOUR_PHONE_NUMBER&text=${encodeURIComponent(message)}';

    window.open(whatsappURL, '_blank');
}