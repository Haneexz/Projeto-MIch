

// Temas do botão Switch
const themeToggle = document.getElementById('checkbox');

if (localStorage.darkModeBlog === 'true') {
    themeSwitch();
    themeToggle.checked = true;
}

themeToggle.addEventListener('click', themeSwitch);

console.log(document.body.dark);

function themeSwitch() {
    document.body.classList.toggle('dark'); // Alterna a classe 'dark' no body

    if (document.body.classList.contains('dark')) {
        localStorage.darkModeBlog = 'true'; // Salva no localStorage que o tema é escuro
    } else {
        localStorage.darkModeBlog = 'false'; // Salva no localStorage que o tema é claro
    }
}