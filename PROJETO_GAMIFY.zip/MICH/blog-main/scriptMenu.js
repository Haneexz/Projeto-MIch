

// Aqui estamos selecionando o menu (o botão ou ícone de menu)
const menu = document.querySelector('.menu')

// Selecionamos a lista de navegação (os links que aparecem no menu)
const navList = document.querySelector('.nav-list')

// Selecionamos todos os itens da lista de navegação (os links individuais)
const navLinks = document.querySelectorAll('.nav-list li')

// Estamos dizendo que quando o menu for clicado, a função handleClick será chamada
menu.addEventListener('click', handleClick)

// Função que acontece quando o menu é clicado
function handleClick () {
    // A linha abaixo vai adicionar ou remover a classe 'active' da lista de navegação (os links)
    navList.classList.toggle('active')
    
    // Também adiciona ou remove a classe 'active' do próprio menu (o botão de menu)
    menu.classList.toggle('active')

    // A função animateLinks vai ser chamada para animar os links quando o menu for aberto
    animateLinks()

    // Verifica se o menu está aberto e se a largura da tela é menor ou igual a 600 pixels (celular)
    if (menu.classList.contains('active') && document.body.offsetWidth <= 600) {
        // Se estiver no celular e o menu estiver aberto, desabilita o rolar da página (fazendo a tela fixa)
        document.body.style.overflowY = 'hidden'
    } else {
        // Se não estiver no celular ou o menu não estiver aberto, o rolar da página fica normal
        document.body.style.overflowY = 'initial'
    }
}

// Função que vai animar os links dentro do menu
function animateLinks() {
    // Para cada link na lista de navegação (os itens de menu), vamos fazer uma animação
    navLinks.forEach((link, index) => {
        // Verifica se o link já tem uma animação aplicada
        link.style.animation
            // Se o link já tem animação, tira essa animação
            ?(link.style.animation = "")
            // Se o link não tem animação, aplica uma animação que faz o link aparecer um por um
            :(link.style.animation = `navLinkFade 0.5s ease forwards ${index / 9 + 0.3}s`)
    })
}
