
function toggleChat() {
    const chatPopup = document.getElementById('chatPopup');
    chatPopup.style.display = chatPopup.style.display === 'none' || chatPopup.style.display === '' ? 'block' : 'none';
}

function sendWhatsAppMessage() {
    const name = document.getElementById('name').value;
    const phone = document.getElementById('phone').value;
    const email = document.getElementById('email').value;
    const role = document.getElementById('role').value;
  

    if (!name || !phone || !email || !role ) {
        alert('Por favor, preencha todos os campos obrigatórios.');
        return;
    }

    const message = `Olá, meu nome é ${name}.\nCargo: ${role}\nEmail: ${email}\nTelefone: ${phone}`;
    const whatsappURL = `https://api.whatsapp.com/send?phone=YOUR_PHONE_NUMBER&text=${encodeURIComponent(message)}`;

    window.open(whatsappURL, '_blank');
}
