// Seleciona todos os artigos no blog, incluindo os das seções principal e lateral
const articles = document.querySelectorAll('.article-text');

// Seleciona o campo de entrada de pesquisa
const inputField = document.querySelector('.input-container input');

// Seleciona os botões de pesquisa
const searchButton = document.querySelector('.search-button');
const searchButtonMobile = document.querySelector('.search-button-mobile');

// Adiciona eventos de clique aos botões de pesquisa
searchButton.addEventListener('click', () => performSearch(inputField.value));
searchButtonMobile.addEventListener('click', () => performSearch(inputField.value));

// Função que realiza a busca
function performSearch(query) {
    // Normaliza o texto digitado pelo usuário (remove espaços e coloca tudo em minúsculas)
    const normalizedQuery = query.trim().toLowerCase();

    // Flag para verificar se algum artigo corresponde à pesquisa
    let found = false;

    // Itera por todos os artigos para verificar se contêm o texto buscado
    articles.forEach(article => {
        // Texto completo do artigo (título, data e parágrafo)
        const articleText = article.innerText.toLowerCase();

        // Verifica se o texto do artigo contém o texto buscado
        if (articleText.includes(normalizedQuery)) {
            // Exibe o artigo correspondente
            article.closest('a').style.display = 'block';
            found = true; // Indica que pelo menos um artigo foi encontrado
        } else {
            // Oculta o artigo que não corresponde à pesquisa
            article.closest('a').style.display = 'none';
        }
    });

    // Caso nenhum artigo seja encontrado, exibe uma mensagem de erro
    if (!found) {
        displayNoResultsMessage(query);
    } else {
        removeNoResultsMessage();
    }

    // Limpa o campo de pesquisa após a busca
    inputField.value = "";
}

// Função para exibir uma mensagem de "Nenhum resultado encontrado"
function displayNoResultsMessage(query) {
    // Verifica se a mensagem já existe para evitar duplicação
    let errorMessage = document.querySelector('.no-results');
    if (!errorMessage) {
        errorMessage = document.createElement('p');
        errorMessage.className = 'no-results';
        errorMessage.textContent = `Nenhum resultado encontrado para "${query}".`;
        document.querySelector('.main-content').appendChild(errorMessage);
    }
}

// Função para remover a mensagem de "Nenhum resultado encontrado"
function removeNoResultsMessage() {
    const errorMessage = document.querySelector('.no-results');
    if (errorMessage) {
        errorMessage.remove();
    }
}