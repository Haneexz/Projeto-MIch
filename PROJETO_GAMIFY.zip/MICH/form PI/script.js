document.getElementById('contact-form').addEventListener('submit', function(event) {
    event.preventDefault(); // Impede o envio do formulário

    // Obtém os valores dos campos
    const name = document.getElementById('name').value;
    const email = document.getElementById('email').value;
    const Telefone = document.getElementById('Telefone').value;
    // Validação simples
    if (!name || !email || !Telefone ) {
        showResponseMessage('Todos os campos são obrigatórios!', 'error');
        return;
    }

    // Simula o envio do formulário (aqui você faria a requisição para o servidor)
    setTimeout(() => {
        showResponseMessage('Sua mensagem foi enviada com sucesso!', 'success');
        // Limpar o formulário após envio bem-sucedido
        document.getElementById('contact-form').reset();
    }, 1500);
});

function showResponseMessage(message, type) {
    const responseMessage = document.getElementById('response-message');
    responseMessage.textContent = message;
    responseMessage.classList.remove('error', 'success');
    responseMessage.classList.add(type);
    responseMessage.style.display = 'block';
}
