// 



function escolha(quizNumber) {
    const select = document.getElementById(`quiz${quizNumber}`);
    const selectedValue = select.value;
    
    // Respostas corretas atualizadas para as novas perguntas
    const correctAnswers = {
        1: 'b) Um tipo de conta para guardar dinheiro',       
        2: 'b) Controlar e planejar gastos e ganhos',
        3: 'a) Um método de pagamento parcelado',
        4: 'a) Uma empresa que mistura finanças e tecnologia',
        5: 'b) Compreender como gerenciar dinheiro de forma responsável',
        6: 'a) Facilitar pagamentos e transferências instantâneas',
        7: 'a) Aplicar dinheiro esperando rendimento futuro',
        8: 'b) Estar preparado para imprevistos financeiros',
        9: 'b) Facilitar o controle e acesso aos recursos financeiros'
    };

    const img = document.getElementById(`imagem${quizNumber}`);

    if (selectedValue === correctAnswers[quizNumber]) {
        img.src = 'img/certo.png';  // Exibe o ícone de resposta certa
        img.style.display = 'block';
    } else if (selectedValue !== '') {
        img.src = 'img/errado.png'; // Exibe o ícone de resposta errada
        img.style.display = 'block';
    } else {
        img.style.display = 'none'; // Oculta a imagem caso não haja resposta selecionada
    }
}
