function escolha(quizNumber) {
    const select = document.getElementById(`quiz${quizNumber}`);
    const selectedValue = select.value;
    
    // Respostas corretas atualizadas para as novas perguntas
    const correctAnswers = {
        1: 'a) A criação de sites e interfaces digitais',
        2: 'a) A capacidade do site de ser acessado de diferentes dispositivos e tamanhos de tela',
        3: 'a) Uma linguagem de marcação para criar a estrutura de páginas web',
        4: 'a) A experiência do usuário ao interagir com um site',
        5: 'a) A linguagem usada para estilizar e formatar a aparência de uma página web',
        6: 'a) Um conjunto de ferramentas e recursos para agilizar o desenvolvimento de sites',
        7: 'a) Um design que se adapta automaticamente a diferentes tamanhos de tela',
        8: 'a) Um elemento de design que exibe imagens ou conteúdo de forma interativa',
        9: 'a) Melhorar a experiência do usuário em dispositivos móveis'
    };

    const img = document.getElementById(`imagem${quizNumber}`);

    if (selectedValue === correctAnswers[quizNumber]) {
        img.src = 'img/certo.png';  // Exibe o ícone de resposta certa
        img.style.display = 'block';
    } else if (selectedValue !== '') {
        img.src = 'img/errado.png'; // Exibe o ícone de resposta errada
        img.style.display = 'block';
    } else {
        img.style.display = 'none'; // Oculta a imagem caso não haja resposta selecionada
    }
}
